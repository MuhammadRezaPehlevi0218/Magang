@extends('layouts.main-layout')
@section('home')
    <div class="home-container">
        <h1>
            HOME PAGE
        </h1>
    </div>
@endsection
