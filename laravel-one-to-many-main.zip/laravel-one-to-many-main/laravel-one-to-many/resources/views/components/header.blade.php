<header>
    <ul>
        <li>Logo</li>
        <li>
            <a href="{{ route('home') }}">Home</a>
        </li>
        <li>
            <a href="{{ route('tasks.index') }}">Tasks</a>
        </li>
        <li>
            <a href="{{ route('employees.index') }}">Employees</a>
        </li>
        <li>
            <a href="{{ route('typologies.index') }}">Typologies</a>
        </li>

    </ul>
</header>
